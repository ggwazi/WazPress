# WazPress

Developer‑first WordPress + WooCommerce distribution.

Goals:
- reproducible WordPress environment
- preset theme and plugin architecture
- Git + CLI directly in wp-admin
- MIT licensed and fully open source

See docs/AGENT.MD for agent workflow and automation policies.