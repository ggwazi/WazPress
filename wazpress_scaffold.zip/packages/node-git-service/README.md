# Node Git Service

Microservice providing:

- git operations
- terminal bridge
- wp-cli execution