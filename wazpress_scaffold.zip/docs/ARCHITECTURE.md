# WazPress Architecture

Core layers:

1. Bedrock WordPress core
2. Custom theme (waz-base-theme)
3. Admin framework plugin (waz-admin)
4. Terminal plugin (waz-terminal)
5. Node Git service (packages/node-git-service)

Primary features:

- Git status inside wp-admin
- Browser terminal via xterm.js
- WooCommerce ready theme
- Devcontainer development